package exceptions;

public class Testing {
	
	public static void temp(int a) {
		
	}

}
