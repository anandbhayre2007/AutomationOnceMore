package constructor;

public class CarUser2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Car car1= new Car("Skoda","Petrol",180);
		car1.features();

	}

}
