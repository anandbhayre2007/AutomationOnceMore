package loops;

public class DoWhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=10;
		
		do {
			System.out.println(a);
			
			a++;
		}while(a<10);

	}

}
