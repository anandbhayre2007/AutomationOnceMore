package loops;

public class WhileLoop {

	public static void main(String[] args) {
		
		//Initialization
		int i=10;
		
		while(i<10) //condition 99%
		{
			System.out.println(i);
			
			i++;//increment
			
		}

	}

}
