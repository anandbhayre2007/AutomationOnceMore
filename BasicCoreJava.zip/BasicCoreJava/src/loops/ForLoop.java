package loops;

public class ForLoop {

	public static void main(String[] args) {
		
			//initialization        //condition    //increment/decrement
		for(int i=0;                  i<=10;         i++)
		{
			System.out.println(i); 
		}

	}

}
