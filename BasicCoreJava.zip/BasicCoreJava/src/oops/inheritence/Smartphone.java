package oops.inheritence;

public class Smartphone extends Mobile{
	
	public void videoCalling()
	{
		System.out.println("Video calling from Smartphone");
	}
	
	
}
