package oops.inheritence;

public class Mobile extends Telephone{

	public void texting()
	{
		System.out.println("Texting from Mobile");
	}
	
	public void calling()
	{
		System.out.println("Calling from mobile");
	}
	
	
}
