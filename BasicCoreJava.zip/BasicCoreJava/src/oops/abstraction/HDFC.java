package oops.abstraction;

public class HDFC implements RBI, GOI{

	
	
	public void savingAccount() {
		System.out.println("HDFC Saving Account");
	}

	public void currentAccount() {
		System.out.println("HDFC Current Account");
	}

	public void debitCard() {
		System.out.println("HDFC Debit Card");
	}

	public void creditCard() {
		System.out.println("HDFC Credit Card");
	}

}
