package oops.abstraction;

public class ICICI implements RBI{


	public void savingAccount() {
		System.out.println("ICICI Saving Account");
	}

	public void currentAccount() {
		System.out.println("ICICI Current Account");
	}

	public void debitCard() {
		System.out.println("ICICI Debit Card");
	}

	public void creditCard() {
		System.out.println("ICICI Credit Card");
	}
}
