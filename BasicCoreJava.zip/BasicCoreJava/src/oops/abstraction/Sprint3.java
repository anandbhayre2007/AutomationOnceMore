package oops.abstraction;

public class Sprint3 extends Sprint2 {

	@Override
	public void print() {
		System.out.println("Print feature");
	}

	@Override
	public void cut() {
		System.out.println("Cut feature");
	}

}
