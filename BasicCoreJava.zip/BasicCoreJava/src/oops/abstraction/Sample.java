package oops.abstraction;

public abstract  class Sample {

	public void santosh()
	{
		
	}
	
	public void Shubhangi() {
		
	}
	
	public abstract void Anjali();
	
}
