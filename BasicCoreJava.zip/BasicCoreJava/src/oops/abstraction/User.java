package oops.abstraction;

public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MsWord ms= new Sprint3();
		
		ms.copy();
		ms.cut();
		ms.paste();
		ms.print();
		ms.edit();
		ms.save();

	}

}
