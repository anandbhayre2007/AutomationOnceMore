package oops.abstraction;

public abstract  class Sprint1 extends MsWord{

	@Override
	public void save() {
		System.out.println("Save feature");
	}

	@Override
	public void edit() {
		System.out.println("Edit feature");
	}

	public void santosh()
	{
		
	}
	

}
