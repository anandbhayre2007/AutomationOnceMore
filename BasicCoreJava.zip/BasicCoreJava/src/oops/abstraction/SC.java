package oops.abstraction;

public interface SC {
	
	public static void COI()
	{
		System.out.println("COI");
	}

}
