package oops.abstraction;

public interface GOI {

	default void demonetization()
	{
		System.out.println("1000 and 500 currencies are invalid");
	}
	default void savingAccount(int a) {
		System.out.println("Anand");
	};
}
