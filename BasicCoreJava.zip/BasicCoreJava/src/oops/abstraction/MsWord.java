package oops.abstraction;

public abstract  class MsWord {

	public abstract void save(); 
	public abstract void edit();
	public abstract void paste();
	public abstract void copy();
	public abstract void print();
	public abstract void cut();
	
}
