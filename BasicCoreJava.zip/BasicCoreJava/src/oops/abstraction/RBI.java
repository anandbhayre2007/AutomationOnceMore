package oops.abstraction;

public interface RBI extends GOI, SC {
	
	public void savingAccount();
	public void currentAccount();
	public void debitCard();
	public void creditCard();
	
}
