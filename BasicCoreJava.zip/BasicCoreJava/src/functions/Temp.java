package functions;

public class Temp {

	public static void main(String[] args) {
		
		int var=ReturnType.sum(10, 20);
		
		int a=10;
		System.out.println(); 
		ReturnType obj= new ReturnType();
		obj.message("Sample message");
		
		
		//1. need give one integer
		//2.  how many ways we have to give an integer value
		//1. hard coded int
		//2. in form of variable
		//3. in for of function
	}

}
