package arrays;

public class Assignment1 {

	public static void main(String[] args) {
		
		//1, 100
		//2, 200
		//3, 300
		//4, 400
		
		int[][] arr= new int[4][2];
		
		arr[0][0]=1;
		arr[0][1]=100;
		
		arr[1][0]=2;
		arr[1][1]=200;
		
		arr[2][0]=3;
		arr[2][1]=300;
		
		arr[3][0]=4;
		arr[3][1]=400;
		/*
		for(int r=0; r<4; r++)
		{
			for(int c=0; c<2; c++)
			{
				System.out.println(arr[r][c]);
			}
		}*/

	}

}
