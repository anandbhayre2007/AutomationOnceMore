package variablesAndDatatypes;

public class JavaFirstClass {

	public static void main(String[] args) {
		
		System.out.println("Selenium class");
		
		

	}
	
	//Assignment 1: Total reserved keywords in java

}
