package variablesAndDatatypes;

public class JavaClass2 {

	public static void main(String[] args) {
		
		//anand, M, 32, true, 5.9
		
		//Local variables
		String name="anand";
		char gender='M';
		int age=32;
		boolean marritalStatus=true;
		double height=5.9;
		
		//char, boolean, byte, short, int, long, float, double
		//byte, short, int & long ==>>difference
		//double & float ==>>difference
		
		//local, class, instance
		
		

	}

}
