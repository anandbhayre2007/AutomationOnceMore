package conditionalStatements;

public class ConditionalStatements1 {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		
		System.out.println(a>b);
		
		if (a>b) {
			System.out.println("a is greater than b");
		}else {
			System.out.println("b is greater than a");
		}
		
	}

}
